<?php

namespace PHPSTORM_META;

override(\Mockery::mock(0), map(["" => "@"]));
override(\Mockery::spy(0), map(["" => "@"]));
override(\Mockery::namedMock(0), map(["" => "@"]));
override(\Mockery::instanceMock(0), map(["" => "@"]));
override(\mock(0), map(["" => "@"]));
override(\spy(0), map(["" => "@"]));
override(\namedMock(0), map(["" => "@"]));