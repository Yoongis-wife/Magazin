<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 200px;">
                    <h4 class="text-center">Заказ № <?php echo e($order['order']->id); ?></h4><br>
                    <button type="button" class="btn btn-info text-white btn-outline-secondary " onclick="window.location.href = '<?php echo e(URL::to('admin/order/'.$order['order']->id)); ?>'">Просмотреть</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/CatalogOrders.blade.php ENDPATH**/ ?>