<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->isAdmin): ?>
                <button type="button" class="btn btn-success text-white btn-outline-secondary m-4" onclick="window.location.href = '<?php echo e(URL::to('/admin/addprod')); ?>'">Add</button>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card shadow-sm">
                     <div><?php echo e($product['product']->name); ?></div>
                        <?php if($product['product']->image == null): ?>
                            <img src="<?php echo e(url('/img/noroot.png')); ?>" alt="Printer">
                        <?php else: ?>
                            <img src="<?php echo e(url('/img/'.$product['product']->image)); ?>" alt="Printer">
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('catalog/pr/'.$product['product']->id)); ?>'">View</button>

                                    <?php if(Auth::check()): ?>
                                        <?php if(Auth::user()->isAdmin): ?>
                                            <button type="button" class="btn btn-warning text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/changeprod/'.$product['product']->id)); ?>'">Change</button>
                                            <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/remove/'.$product['product']->id)); ?>'">Delete</button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <small class="text-body-secondary"><?php echo e($product['product']->date); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\Shop\resources\views/Catalog.blade.php ENDPATH**/ ?>