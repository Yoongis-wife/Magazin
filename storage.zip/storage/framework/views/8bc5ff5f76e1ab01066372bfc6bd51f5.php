<?php $__env->startSection('content'); ?>

<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin): ?>
        <div class="d-grid justify-content-center">
        <h1>Заказы</h1>

        <?php if($orders!=null): ?>
            <div class="accordion" id="accordionExample" style="width: 600px">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($order['order']->id); ?>" aria-expanded="true" aria-controls="<?php echo e($order['order']->id); ?>">
                                Заказ <?php echo e($order['order']->id); ?> | <?php echo e($order['status']); ?>

                            </button>
                        </h2>
                        <?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="<?php echo e($order['order']->id); ?>" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p><?php echo e($product['product']->name); ?></p>
                                    <p><?php echo e($product['product']->country); ?></p>
                                    <p><?php echo e($product['product']->model); ?></p>
                                    <p><?php echo e($product['count']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <p><?php echo e($order['user']->surname); ?> <?php echo e($order['user']->name); ?> <?php echo e($order['user']->patronymic); ?></p>
                        <br>
                        <?php echo e($order['order']->created); ?>

                        <br>
                            <button type="button" class="btn btn-dark btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/admin/orders/rem/'.$order['order']->id)); ?>'" >Удалить заказ</button>
                            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($order['order']->id); ?>" class="btn btn-dark btn-outline-secondary text-white h3">Изменить статус</button>
                        <br>
                    </div>

                <div class="modal fade" id="exampleModal<?php echo e($order['order']->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h1>Выберите статус</h1>
        <form action="<?php echo e(URL::to('/admin/orders/change/'.$order['order']->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-floating m-2">
            <select type="password" name="status" class="form-control" id="floatingPassword">
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="floatingPassword">Выберите статус</label>
        </div>

        <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Accept</button>
        </form>
      </div>
    </div>
  </div>
</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>




        <?php else: ?>
            <h2>На данный момент нет заказов</h2>
        <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="d-grid ">
        <h1>Заказы</h1>

        <?php if($orders!=null): ?>
            <div class="accordion" id="accordionExample">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($order['order']->id); ?>" aria-expanded="true" aria-controls="<?php echo e($order['order']->id); ?>">
                                Заказ <?php echo e($order['order']->id); ?> | <?php echo e($order['status']); ?>

                            </button>
                        </h2>
                        <?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="<?php echo e($order['order']->id); ?>" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p><?php echo e($product['product']->name); ?></p>
                                    <p><?php echo e($product['product']->country); ?></p>
                                    <p><?php echo e($product['product']->model); ?></p>
                                    <p><?php echo e($product['count']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($order['order']->id_status==1): ?>
                            <button  type="button" class="btn btn-dark btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/order/remove/'.$order['order']->id)); ?>'">Отменить заказ</button>
                        <?php endif; ?>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/Order.blade.php ENDPATH**/ ?>