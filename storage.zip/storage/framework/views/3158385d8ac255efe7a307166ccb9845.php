<?php $__env->startSection('content'); ?>

<?php if(isset($product)): ?>
<form method="POST" action="<?php echo e(URL::to('/admin/changeprod/'.$product->id)); ?>" class="w-50 m-auto" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-normal">Изменить продукт</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="<?php echo e($product->name); ?>" placeholder="name">
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="<?php echo e($product->date); ?>" placeholder="Date">
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Date">
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="<?php echo e($product->price); ?>" placeholder="Date">
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <select name="id_type" class="form-select">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="floatingPassword">Type</label>
    </div>
    <div class="form-floating m-2">
        <input name="country" class="form-control" id="floatingPassword" value="<?php echo e($product->country); ?>" placeholder="Date">
        <label for="floatingPassword">Country</label>
    </div>
    <div class="form-floating m-2">
        <input name="model" class="form-control" id="floatingPassword" value="<?php echo e($product->model); ?>" placeholder="Date">
        <label for="floatingPassword">Model</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Change</button>
</form>
<?php else: ?>
<form method="POST" action="<?php echo e(URL::to('/admin/addprod')); ?>" class="w-50 m-auto" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-normal">Добавить новый продукт</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" placeholder="name">
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Date">
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <select name="id_type" class="form-select">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="floatingPassword">Type</label>
    </div>
    <div class="form-floating m-2">
        <input name="country" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Country</label>
    </div>
    <div class="form-floating m-2">
        <input name="model" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Model</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Add</button>
</form>

<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/AddProduct.blade.php ENDPATH**/ ?>