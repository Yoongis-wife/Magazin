<?php $__env->startSection('content'); ?>

<div class="justify-content-center row w-75 m-auto">
    <div class="col"><?php if($product->image == null): ?>
            <img src="../img/noroot.png" alt="Printer" class="w-50">
            <?php else: ?>
                <img src="../img/<?php echo e($product->image); ?>" alt="Printer" class="w-50">
            <?php endif; ?></div>
    <div class="col">
        <h1><?php echo e($product->name); ?></h1>
        <p>Стоимость: <?php echo e($product->price); ?></p>
        <p>Тип принтера: <?php echo e($type); ?></p>
        <p>Страна производитель: <?php echo e($product->country); ?></p>
        <p>Модель: <?php echo e($product->model); ?></p>
        <?php if(Auth::check()): ?>
        <button class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$product->id)); ?>'">Добавить в корзину</button>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\Shop\resources\views/Product.blade.php ENDPATH**/ ?>