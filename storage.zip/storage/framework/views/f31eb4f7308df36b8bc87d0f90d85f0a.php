<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->isAdmin): ?>
                <button type="button" class="btn btn-success text-white btn-outline-secondary m-4" onclick="window.location.href = '<?php echo e(URL::to('/admin/addprod')); ?>'">Добавить товар</button>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 300px;">
                        <a href="<?php echo e(URL::to('catalog/pr/'.$product['product']->id)); ?>"><img src="<?php echo e(url('/img/'.$product['product']->image)); ?>" alt="" style="width:290px"></a>
                        <h4><?php echo e($product['product']->name); ?></h4>
                        <h5><?php echo e($product['product']->price); ?> р.</h5>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">

                                    <?php if(Auth::check()): ?>
                                        <?php if(Auth::user()->isAdmin): ?>
                                            <button type="button" class="btn btn-info text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/changeprod/'.$product['product']->id)); ?>'">Изменить</button>
                                            <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/remove/'.$product['product']->id)); ?>'">Удалить</button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/Catalog.blade.php ENDPATH**/ ?>