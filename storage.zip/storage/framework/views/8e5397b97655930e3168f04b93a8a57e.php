<?php $__env->startSection('content'); ?>
    <div class="m-5 row">
        <div class="col">
            <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Ab9b36215bbb1ee62630bac610423cb692d5c0d11445a4df9a72d78337c26ad39&amp;source=constructor" width="633" height="400" frameborder="0"></iframe>
        </div>
        <div class="col">
            <strong><p class="m-2">Адрес: г.Каменск- ул.Тевосяна д.5</p></strong>
            <strong><p class="m-2">Контактный телефон: +7-800-535-35-35</p></strong>
            <strong><p class="m-2">Эл. почта: niki@mail.ru</p></strong>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/map.blade.php ENDPATH**/ ?>