<?php $__env->startSection('content'); ?>
<div class="d-grid justify-content-center">
    <h1>Ваша корзина</h1>
    <?php if($products!=null): ?>
<div class="album py-5 bg-body-tertiary">
    <div class="container">
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col">
    <div class="card shadow-sm">
            <div><?php echo e($product['product']->name); ?></div>
            <?php if($product['product']->image == null): ?>
            <img src="../public/img/noroot.png" alt="Printer">
            <?php else: ?>
                <img src="../public/img/<?php echo e($product['product']->image); ?>" alt="Printer">
            <?php endif; ?>
            <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-success rounded-pill btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$product['product']->id.'/1')); ?>'">+</button>
                    <p class="h3 p-2"><?php echo e($product['count']); ?></p>
                    <button type="button" class="btn btn-danger rounded-pill btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/remove/'.$product['product']->id)); ?>'">-</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br>
<button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-success rounded-pill btn-outline-secondary text-white h3">Оформить заказ | <?php echo e($p); ?></button>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h1>Подтвердите</h1>
        <form action="<?php echo e(URL::to('/order/new')); ?>" method="POST"
        <?php if(isset($_POST["password"])): ?>
        onsubmit='event.preventDefault();
        alert("lol");
        let p = document.querySelector(".password");

        if (<?php echo e(Auth::atempt(["email"=>Auth::user()->email, ["password"=> $_POST["password"]]])); ?>) {
            document.querySelector("form").submit();
        }
        return false;'
        <?php endif; ?>>
        <?php echo csrf_field(); ?>

        <div class="form-floating m-2">
            <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
            <label for="floatingPassword">Password</label>
        </div>

        <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Accept</button>
        </form>
      </div>
    </div>
  </div>
</div>

    </div>
</div>
    <?php else: ?>
    <h2>На данный момент они пуста</h2>
    <?php endif; ?>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\Shop\resources\views/Korzina.blade.php ENDPATH**/ ?>