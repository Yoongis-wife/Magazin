<?php $__env->startSection('content'); ?>
<div class="d-grid justify-content-center">
    <h1>Ваша заказы</h1>

    <?php if($orders!=null): ?>
<div class="accordion" id="accordionExample">
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($order['order']->id); ?>" aria-expanded="true" aria-controls="<?php echo e($order['order']->id); ?>">
                Заказ <?php echo e($order['order']->id); ?> | <?php echo e($order['status']); ?>

            </button>
        </h2>
    <?php $__currentLoopData = $order['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="<?php echo e($order['order']->id); ?>" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
            <div class="accordion-body">
                <p><?php echo e($product['product']->name); ?></p>
                <p><?php echo e($product['product']->country); ?></p>
                <p><?php echo e($product['product']->model); ?></p>
                <p><?php echo e($product['count']); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($order['order']->id_status==1): ?>
            <button type="button" class="btn btn-danger rounded-pill btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/order/remove/'.$order['order']->id)); ?>'">-</button>
        <?php endif; ?>
        <br>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <?php else: ?>
    <h2>На данный момент она пуста</h2>
    <?php endif; ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\Shop\resources\views/order.blade.php ENDPATH**/ ?>