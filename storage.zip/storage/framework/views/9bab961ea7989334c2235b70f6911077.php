<?php $__env->startSection('content'); ?>

<?php if(Auth::check()): ?>
    <?php if(Auth::user()->isAdmin): ?>
        <div class="d-grid justify-content-start ms-5">
        <?php if($order!=null): ?>
            <h1>Заказ № <?php echo e($order->id); ?></h1>
            <h2>Статус заказа: <?php echo e($status); ?></h2>
            <h4>Товары</h4>
            <div class="row row-cols-2 row-cols-sm-2 row-cols-md-3 g-3">
                 <div class="col">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card" style="width: 250px; margin-bottom:20px">
                        <h5>Название: <?php echo e($product['product']->name); ?></h5>
                        <h5>Производитель: <?php echo e($product['product']->country); ?></h5>
                        <h5>Модель: <?php echo e($product['product']->model); ?></h5>
                        <h5>Кол-во: <?php echo e($product['count']); ?></h5>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            </div>
            <h4>Покупатель: <?php echo e($user->surname); ?> <?php echo e($user->name); ?> <?php echo e($user->patronymic); ?></h4>
            <h4>Дата создания: <?php echo e($order->created); ?></h4>
            <form action="<?php echo e(URL::to('/admin/order/rem/'.$order->id)); ?>" method="POST" >
                <?php echo e(method_field('DELETE')); ?>

                <?php echo csrf_field(); ?>
                <button style="width:180px" type="submit" class="btn btn-dark btn-outline-secondary text-white h3">Удалить заказ</button>
            </form>
            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($order->id); ?>" class="btn btn-dark btn-outline-secondary w-50 text-white h3">Изменить статус</button>
        </div>
                <div class="modal fade" id="exampleModal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h1>Выберите статус</h1>
        <form action="<?php echo e(URL::to('/admin/orders/change/'.$order->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-floating m-2">
            <select type="password" name="status" class="form-control" id="floatingPassword">
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="floatingPassword">Выберите статус</label>
        </div>

        <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Accept</button>
        </form>
      </div>
    </div>
  </div>
</div>
        </div>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\Shop\resources\views/OneOrder.blade.php ENDPATH**/ ?>