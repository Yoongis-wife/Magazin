<?php $__env->startSection('content'); ?>
    <div class="m-5" style="display: grid; justify-items: center;">
        <iframe src="https://yandex.ru/map-widget/v1/?ll=61.931239%2C56.416834&mode=search&ol=geo&ouri=ymapsbm1%3A%2F%2Fgeo%3Fdata%3DCgg1MzE1OTM5ORJY0KDQvtGB0YHQuNGPLCDQodCy0LXRgNC00LvQvtCy0YHQutCw0Y8g0L7QsdC70LDRgdGC0YwsINCa0LDQvNC10L3RgdC6LdCj0YDQsNC70YzRgdC60LjQuSIKDcqrd0IVNalhQg%2C%2C&source=serp_navig&z=11.47" width="560" height="400" frameborder="1" allowfullscreen="true" style="position:relative;"></iframe>
        <h2>
            <p class="m-2">
                г. Каменск-Уральский
            </p>
            <p class="m-2">
                ул. Беброва 4<br>
            </p>
            <p class="m-2">
                +7-908-908-98-98<br>
            </p>
            <p class="m-2">
                example@mail.ru
            </p>
        </h2>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\localhost\Shop\resources\views/map.blade.php ENDPATH**/ ?>