<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Korzina extends Model
{
    use HasFactory;
    public $fillable = [
        'id_user',
        'isOld'
    ];

    public $timestamps = false;
}
