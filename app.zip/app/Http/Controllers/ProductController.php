<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Type_product;

class ProductController extends Controller
{
    public function All($s=null, $p=null){
        $products = [];
        $pr = Product::all();
        if ($s != null) {
            if($p == null)
            {
                $pr = Product::where('id_type',$s)->get();
            }
            if($p == 1)
            {
                $pr = Product::orderBy('price')->where('id_type',$s)->get();

            }

            if($p == 2)
            {
                $pr = Product::orderBy('price', 'DESC')->where('id_type',$s)->get();
            }
        }
        if ($s == null) {
            if($p == 1)
            {
                $pr = Product::orderBy('price');
            }

            if($p == 2)
            {
                $pr=Product::orderBy('price','DESC');

            }
        }

        foreach ($pr as $p) {
            $products[] = ['product'=>$p,"type"=>Type_product::find($p->id_type)->name];
        }

        return view('Catalog',['products'=>$products]);
    }

    public function One($id){
        return view('Product',['product'=>Product::find($id), 'type'=>Type_product::find(Product::find($id)->id_type)->name]);
    }

    public function About(){
        $products = Product::orderByDesc('date')->take(5)->get()->sort();
        return view('AboutUs', ['products'=>$products]);
    }
}
