<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Order;
use App\Models\Korzina_product;
use App\Models\Statu;


use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function NewOrder(Request $request){
        if(Auth::check()){
            $user = Auth::user();
            $field = $request->validate(['password'=>'required',]);
            if (Auth::attempt(['email' => $user->email, 'password' => $field['password']])) {
                # code...
                $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>0])->get()[0];
                if (Korzina_product::where(['id_korzina'=>$korz->id])->first()!==null) {
                    $order = Order::create(['id_korzina'=>$korz->id,'created'=>date('y-m-d')]);
                    $korz->isOld = true;
                    $korz->save();
                    $this->CreateKorzina();
                    return redirect('/order');
                }
            }
            return redirect('/korzina');
        }
    }

    public function GetOrder(){
        $orders = [];
        $products = [];
        if(Auth::check()){

            $user = Auth::user();
            $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>1])->get();

            foreach ($korz as $k) {
                $kps = Korzina_product::where('id_korzina',$k->id)->get();
                $order = Order::where('id_korzina',$k->id)->first();
                foreach ($kps as $kp) {
                    array_push($products,['product'=>Product::find($kp->id_product),'count'=>$kp->count]);
                }
                array_push($orders, ['order'=>$order,'user'=>$user,'products'=>$products, 'status'=>Statu::find($order->id_status)->name]);
            }
            }
            return view('order',['orders'=>$orders]);
    }

    public function RemoveOrder($id){

        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>1])->get();

            foreach ($korz as $k) {
                $order = Order::where(['id_korzina'=>$k->id,'id'=>$id])->first();
                if ($order->id_status==1) {
                    $order->delete();
                    $k->delete();
                    return redirect('/order');
                }
            }

        }

    }




    function CreateKorzina(){
        if (Auth::check()) {
            $user = Auth::user();
            Korzina::create([
                'id_user'=>$user->id,
            ]);
        }
    }
}
