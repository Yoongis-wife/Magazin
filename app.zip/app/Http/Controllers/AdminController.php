<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Order;
use App\Models\Korzina_product;
use App\Models\Type_product;
use Illuminate\Support\Facades\Storage;
use App\Models\Statu;

use function Laravel\Prompts\alert;

class AdminController extends Controller
{
    public function GetCatalog(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $products = [];
                $pr = Product::all();

                foreach ($pr as $p) {
                    $products[] = ['product'=>$p,"type"=>Type_product::find($p->id_type)->name];
                }
                return view('Catalog',['products'=>$products]);
            }
            return redirect('/catalog');
        }
        return redirect('/login');
    }

    public function GetAddProduct(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
        return view('AddProduct',['types'=>Type_product::all()]);
            }
        }
    }

    public function GetChangeProduct($id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                return view('AddProduct',['types'=>Type_product::all(), 'product'=>Product::find($id)]);
            }
        }
    }

    public function ChangeProduct(Request $request, $id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $pr = Product::find($id);
        $validate = $request->validate([
            'name'=>'required',
            'date'=>'required',
            'price'=>'required',
            'model'=>'required',
            'country'=>'required',
            'id_type'=>'required',
        ]);
        $fn = null;
        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $fn = $file->getClientOriginalName();
            $file->move(public_path('img'), $fn);
        }


        $pr->update(['name'=>$validate['name'], 'date'=>$validate['date'],
        'price'=>$validate['price'], 'model'=>$validate['model'], 'country'=>$validate['country'],
        'id_type'=>$validate['id_type'], 'image'=> $fn
        ]);
          return redirect('/admin');
        }
        }
        return redirect('/catalog');
    }

    public function AddProduct(Request $request){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
        $validate = $request->validate([
            'name'=>'required',
            'date'=>'required',
            'price'=>'required',
            'model'=>'required',
            'country'=>'required',
            'id_type'=>'required',
        ]);
        $fn = null;
        if ($request->hasFile('file')) {
            $file = $request->file('file');

            $fn = $file->getClientOriginalName();
            $file->move(public_path('img'), $fn);
        }


        Product::create(['name'=>$validate['name'], 'date'=>$validate['date'],
        'price'=>$validate['price'], 'model'=>$validate['model'], 'country'=>$validate['country'],
        'id_type'=>$validate['id_type'], 'image'=> $fn
        ]   );

        return redirect('/admin');
        }
        }
        return redirect('/catalog');
    }

    public function RemoveProduct($id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $pr = Product::find($id);
                $pr->delete();
             return redirect('/admin');
            }
        }
        return redirect('/catalog');
    }

    public function GetOrders(){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $orders = [];
                $or = Order::all();

                foreach ($or as $o) {
                    $kor = Korzina::find($o->id_korzina);

                    $prs = Korzina_product::where('id_korzina',$kor->id)->get();

                    $products = [];

                    foreach ($prs as $pr) {
                        $products[] = ['product'=>Product::find($pr->id_product),'count'=>$pr->count];
                    }

                    $u = User::find(Korzina::find($o->id_korzina)->id_user);


                    array_push($orders, ['order'=>$o,'user'=>$u,'products'=>$products, 'status'=>Statu::find($o->id_status)->name]);
                }

                return view('CatalogOrders',['orders'=>$orders, 'status'=>Statu::all()]);
            }
            return redirect('/order');
        }
        return redirect('/login');
    }
    public function GetOrder($id){
        $o=Order::find($id);
        $kor = Korzina::find($o->id_korzina);
        $prs = Korzina_product::where('id_korzina',$kor->id)->get();
        $products = [];
        $u = User::find(Korzina::find($o->id_korzina)->id_user);
        foreach ($prs as $pr) {
            $products[] = ['product'=>Product::find($pr->id_product),'count'=>$pr->count];
        }
        return view('OneOrder',['order'=>Order::find($id),'user'=>$u,'products'=>$products, 'status'=>Statu::find($o->id_status)->name, 'statuses'=>Statu::all()]);
    }
    public function RemoveOrder($id){
        if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $order = Order::find($id);
                $korz = Korzina::find($order->id_korzina);
                $order->delete();
                $korz->delete();
                return redirect('/admin/orders');
            }
            else {return redirect('/order');}
        }
        else {return redirect('/login');}
    }

    public function ChangeStatusOrder($id, Request $request){
         if (Auth::check()) {
            if (Auth::user()->isAdmin) {
                $order = Order::find($id);
                $order->id_status=$request->input('status');
                $order->save();
                return redirect('/admin/order/'.$id);
            }
            return redirect('/order');
        }
        return redirect('/login');
    }
}


