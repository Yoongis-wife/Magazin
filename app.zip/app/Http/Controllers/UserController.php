<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Product;
use App\Models\Korzina;
use App\Models\Korzina_product;

class UserController extends Controller
{
    function CreateKorzina(){
        if (Auth::check()) {
            $user = Auth::user();
            Korzina::create([
                'id_user'=>$user->id,
            ]);
        }
    }

    public function SignUp(Request $request){

        $validateFiels = $request->validate([
                'name'=>'required',
                'surname'=>'required',
                'login'=>'required',
                'email'=>'required|email',
                'password'=>'required',
        ]);

        $user = User::where(['login'=>$validateFiels['login'],'email'=>$validateFiels['email']])->first();
        if (!$user) {
        $user = User::create($validateFiels);

            Auth::login($user);
            $this->CreateKorzina();
            return redirect('/catalog');
        }
        return redirect('/register');
    }

    public function SignIn(Request $request){
        $foundFields = $request->only(['login','password']);

        if(Auth::attempt($foundFields))
        {
            if (Auth::user()->isAdmin) {
                return redirect('/admin');
            }
            return redirect('/catalog');
        }

        return redirect('/login');
    }

    public function GetKorzina(){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>0])->get();
            $products = [];
            $kp = Korzina_product::where(['id_korzina'=>$korz[0]->id])->get();
            $p=0;
            foreach ($kp as $k) {
                $pr = Product::where('id',$k->id_product)->get()[0];
                $p+= $pr->price*$k->count;
                array_push($products,['product'=>$pr, 'count'=>$k->count]);
            }
            return view('Korzina',['products'=>$products,'p'=>$p]);
        }

    }

    public function AddToKorzina($id, $c=null){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>0])->get()[0];
            if (Korzina_product::where(['id_korzina'=>$korz->id, 'id_product'=>$id])->first()===null) {
                $kp = Korzina_product::where(['id_korzina'=>$korz->id, 'id_product'=>$id])->get();
                $product = Product::find($id);
                Korzina_product::create(['id_product'=>$product->id, 'id_korzina'=>$korz->id, 'count'=>1]);
            }
            else {
                $kp = Korzina_product::where(['id_korzina'=>$korz->id, 'id_product'=>$id])->get()[0];
                $kp->count++;
                $kp->save();
            }
            if ($c==null) {
                return redirect('/catalog/pr/'.$id);
            }
            return redirect('/korzina');

        }
    }

    public function RemoveFromKorzina($id){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['id_user'=>$user->id, 'isOld'=>0])->get()[0];
            $kp = Korzina_product::where(['id_korzina'=>$korz->id, 'id_product'=>$id])->get()[0];
            $kp->count--;
            $kp->save();
            if ($kp->count<1) {
                $kp->delete();
            }
            return redirect('/korzina');
        }
    }

}
