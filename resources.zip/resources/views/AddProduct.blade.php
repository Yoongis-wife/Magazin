@extends('Layout')
@section('content')

@if(isset($product))
<form method="POST" action="{{URL::to('/admin/changeprod/'.$product->id)}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Изменить продукт</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="{{$product->name}}" placeholder="name">
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="{{$product->date}}" placeholder="Date">
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Date">
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="{{$product->price}}" placeholder="Date">
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <select name="id_type" class="form-select">
            @foreach ($types as $type)
            <option value="{{$type->id}}">{{$type->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Type</label>
    </div>
    <div class="form-floating m-2">
        <input name="country" class="form-control" id="floatingPassword" value="{{$product->country}}" placeholder="Date">
        <label for="floatingPassword">Country</label>
    </div>
    <div class="form-floating m-2">
        <input name="model" class="form-control" id="floatingPassword" value="{{$product->model}}" placeholder="Date">
        <label for="floatingPassword">Model</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Change</button>
</form>
@else
<form method="POST" action="{{URL::to('/admin/addprod')}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Добавить новый продукт</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" placeholder="name">
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Date">
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <select name="id_type" class="form-select">
            @foreach ($types as $type)
            <option value="{{$type->id}}">{{$type->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Type</label>
    </div>
    <div class="form-floating m-2">
        <input name="country" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Country</label>
    </div>
    <div class="form-floating m-2">
        <input name="model" class="form-control" id="floatingPassword" placeholder="Date">
        <label for="floatingPassword">Model</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Add</button>
</form>

@endif



@endsection
@show
