@extends('Layout')
@section('content')

<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach ($orders as $order)
            <div class="col">
                <div class="card " style="width: 200px;">
                    <h4 class="text-center">Заказ № {{$order['order']->id}}</h4><br>
                    <button type="button" class="btn btn-info text-white btn-outline-secondary " onclick="window.location.href = '{{URL::to('admin/order/'.$order['order']->id)}}'">Просмотреть</button>
                </div>
            </div>
        @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
@show
