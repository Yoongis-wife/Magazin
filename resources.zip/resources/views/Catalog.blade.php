@extends('Layout')
@section('content')

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        @if (Auth::check())
            @if (Auth::user()->isAdmin)
                <button type="button" class="btn btn-success text-white btn-outline-secondary m-4" onclick="window.location.href = '{{URL::to('/admin/addprod')}}'">Добавить товар</button>
            @endif
        @endif

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach ($products as $product)
            <div class="col">
                <div class="card " style="width: 300px;">
                        <a href="{{URL::to('catalog/pr/'.$product['product']->id)}}"><img src="{{url('/img/'.$product['product']->image)}}" alt="" style="width:290px"></a>
                        <h4>{{$product['product']->name}}</h4>
                        <h5>{{$product['product']->price}} р.</h5>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">

                                    @if (Auth::check())
                                        @if (Auth::user()->isAdmin)
                                            <button type="button" class="btn btn-info text-white btn-outline-secondary" onclick="window.location.href = '{{URL::to('admin/changeprod/'.$product['product']->id)}}'">Изменить</button>
                                            <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '{{URL::to('admin/remove/'.$product['product']->id)}}'">Удалить</button>
                                        @endif
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
@show
