@if (!Auth::check())
<div class="p-3 text-dark bg-info">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <img src="{{URL::to('/img/logo.png')}}"  alt="..." style="width: 150px;" class="justify-content start">
            <ul class="nav col-10 col-lg-auto me-lg-auto ms-auto justify-content-center mb-md-0">
                <li><a href = '{{URL::to('/catalog')}}' class="nav-link px-2 text-white">Каталог</a></li>
                <li><a href = '{{URL::to('/map')}}' class="nav-link px-2 text-white">Где нас найти?</a></li>
                <li><a class="nav-link px-2 text-white" href = '{{URL::to('/')}}'>О нас</a></li>
            </ul>

        <div class="text-end">
            <button type="button" onclick=" window.location.href = '{{URL::to('/login')}}'" class="btn btn-light text-dark me-2">Войти</button>
            <button type="button" class="btn btn-light text-dark" onclick="window.location.href='{{URL::to('/register')}}'">Зарегистрироваться</button>
        </div>
    </div>

</div>
@endif

@if (Auth::check())
@if (!Auth::user()->isAdmin)
<div class="p-3 mb-3 text-dark bg-info">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <img src="{{URL::to('/img/logo.png')}}"  alt="..." style="width: 150px;" class="justify-content start">

        <ul class="nav col-12 col-lg-auto me-lg-auto ms-auto justify-content-center mb-md-0">
          <li><a href = '{{URL::to('/catalog')}}' class="nav-link px-2 text-white">Каталог</a></li>
                <li><a href = '{{URL::to('/map')}}' class="nav-link px-2 text-white">Где нас найти?</a></li>
                <li><a class="nav-link px-2 text-white" href = '{{URL::to('/')}}'>О нас</a></li>
        </ul>

        <ul class="nav col-12 col-lg-auto me-0 mb-2 justify-content-center mb-md-0">
            <li><a class="nav-link px-2 text-white" href="{{URL::to('/korzina')}}">Корзина</a></li>
            <li><a class="nav-link px-2 text-white" href="{{URL::to('/order')}}">Заказы</a></li>
            <li><a class="nav-link px-2 text-white" href="{{URL::to('/logout')}}">Выйти</a></li>
          </ul>
      </div>
    </div>
</div>
@else
<div class="px-3 py-2 text-dark bg-info">
      <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <img src="{{URL::to('/img/logo.png')}}"  alt="..." style="width: 150px;" class="justify-content start">

          <ul class="nav col-12 col-lg-auto my-2 justify-content-center my-md-0 text-small">
            <li>
              <a href="{{URL::to('/admin')}}" class="nav-link text-white">
                Каталог
              </a>
            </li>
            <li>
              <a href="{{URL::to('/admin/orders')}}" class="nav-link text-white">
                Заказы
              </a>
            </li>
            <li>
              <a href="{{URL::to('/logout')}}" class="nav-link text-white">
                Выйти
              </a>
            </li>
          </ul>
        </div>
      </div>
</div>
@endif

@endif

