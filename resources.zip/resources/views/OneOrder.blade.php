@extends('Layout')
@section('content')

@if (Auth::check())
    @if (Auth::user()->isAdmin)
        <div class="d-grid justify-content-start ms-5">
        @if ($order!=null)
            <h1>Заказ № {{$order->id}}</h1>
            <h2>Статус заказа: {{$status}}</h2>
            <h4>Товары</h4>
            <div class="row row-cols-2 row-cols-sm-2 row-cols-md-3 g-3">
                 <div class="col">
                @foreach ($products as $product)

                    <div class="card" style="width: 250px; margin-bottom:20px">
                        <h5>Название: {{$product['product']->name}}</h5>
                        <h5>Производитель: {{$product['product']->country}}</h5>
                        <h5>Модель: {{$product['product']->model}}</h5>
                        <h5>Кол-во: {{$product['count']}}</h5>
                    </div>

                @endforeach</div>
            </div>
            <h4>Покупатель: {{$user->surname}} {{$user->name}} {{$user->patronymic}}</h4>
            <h4>Дата создания: {{$order->created}}</h4>
            <form action="{{URL::to('/admin/order/rem/'.$order->id)}}" method="POST" >
                {{method_field('DELETE')}}
                @csrf
                <button style="width:180px" type="submit" class="btn btn-dark btn-outline-secondary text-white h3">Удалить заказ</button>
            </form>
            <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal{{$order->id}}" class="btn btn-dark btn-outline-secondary w-50 text-white h3">Изменить статус</button>
        </div>
                <div class="modal fade" id="exampleModal{{$order->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h1>Выберите статус</h1>
        <form action="{{URL::to('/admin/orders/change/'.$order->id)}}" method="POST">
        @csrf

        <div class="form-floating m-2">
            <select type="password" name="status" class="form-control" id="floatingPassword">
                @foreach ($statuses as $s)
                    <option value="{{$s->id}}">{{$s->name}}</option>
                @endforeach
            </select>
            <label for="floatingPassword">Выберите статус</label>
        </div>

        <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Accept</button>
        </form>
      </div>
    </div>
  </div>
</div>
        </div>
@endif
@endif
@endif
@endsection
@show
