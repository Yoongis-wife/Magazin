@extends('Layout')
@section('content')

<div class="justify-content-center row w-75 m-auto">
    <div class="col">@if ($product->image == null)
            <img src="../img/noroot.png" alt="Printer" class="w-50">
            @else
                <img src="../../img/{{$product->image}}" style="width:400px">
            @endif</div>
    <div class="col">
        <h1>{{$product->name}}</h1>
        <p>Стоимость: {{$product->price}}</p>
        <p>Тип принтера: {{$type}}</p>
        <p>Страна производитель: {{$product->country}}</p>
        <p>Модель: {{$product->model}}</p>
        @if (Auth::check())
        <button class="btn btn-primary" onclick="window.location.href = '{{URL::to('/add/'.$product->id)}}'">Добавить в корзину</button>
        @endif
    </div>
</div>

@endsection
@show
