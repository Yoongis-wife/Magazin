@extends('Layout')
@section('content')

@if (Auth::check())
    @if (!Auth::user()->isAdmin)
        <div class="d-grid ">
        <h1>Заказы</h1>
        @if ($orders!=null)
            <div class="accordion" id="accordionExample">
                @foreach ($orders as $order)
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#{{$order['order']->id}}" aria-expanded="true" aria-controls="{{$order['order']->id}}">
                                Заказ {{$order['order']->id}} | {{$order['status']}}
                            </button>
                        </h2>
                        @foreach ($order['products'] as $product)
                            <div id="{{$order['order']->id}}" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p>{{$product['product']->name}}</p>
                                    <p>{{$product['product']->country}}</p>
                                    <p>{{$product['product']->model}}</p>
                                    <p>{{$product['count']}}</p>
                                </div>
                            </div>
                        @endforeach
                        @if ($order['order']->id_status==1)
                            <button  type="button" class="btn btn-dark btn-outline-secondary text-white h3" onclick="window.location.href = '{{URL::to('/order/remove/'.$order['order']->id)}}'">Отменить заказ</button>
                        @endif
                    <br>
                </div>
            @endforeach
        </div>
        @endif
        </div>
        @else
        <h2>На данный момент нет заказов</h2>
    @endif
    </div>
@endif

@endsection
@show
